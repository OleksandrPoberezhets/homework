#include <fstream>
#include <iostream>
#include <cmath>
using namespace std;
 
#define FILENAME_1 "numbers.txt"
 
int main()
{
    int counter=0;
    ifstream file_1;
 
    file_1.open(FILENAME_1);
 
    char temp;
    
    while((temp = file_1.get()) != -1){
        int itemp = temp-'0';
        if(pow(itemp,0.5)==(int)pow(itemp,0.5)&&itemp%2!=0){
            counter++;
        }
            
    }
    file_1.close();
    
    cout << counter;
    
    return 0;
}